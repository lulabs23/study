# Études

Notes, fiches de cours, QCM, emploi du temps, Moodle et mails Unicaen. Même construction que Finances : React + Vite, données dans le téléphone, sauvegarde dans un Gist GitHub privé.

## 1. Mise en ligne

1. Créer un dépôt **public** `etudes` sur GitHub et y déposer tout le contenu de ce dossier (Add file → Upload files), dossier `.github` compris.
2. Settings → Pages → Source : **GitHub Actions**.
3. Le déploiement se lance tout seul. L'application est à l'adresse `https://<compte>.github.io/etudes/`.
4. Sur l'iPhone : Safari → Partager → **Sur l'écran d'accueil**. Elle fonctionne ensuite hors ligne.

## 2. Synchronisation entre appareils (Gist)

1. Créer un token : github.com/settings/personal-access-tokens/new
   - Repository access : *Only select repositories* → `etudes`
   - Repository permissions : **Actions → Read and write** (bouton Actualiser de l'EDT)
   - Account permissions : **Gists → Read and write**
2. Dans l'application : Paramètres → Synchronisation Gist → coller le token → Connecter.
3. Sur les autres appareils, coller le même token : le Gist existant est retrouvé.

Le plus récent l'emporte : une modification faite hors ligne est envoyée au retour du réseau.

## 3. Emploi du temps et mails (automatique)

Le workflow `EDT Unicaen` lit l'agenda « Emploi du temps » et les 40 derniers mails de la boîte de réception du webmail Unicaen, **toutes les 30 minutes** (de 6 h à 22 h environ). Le résultat est écrit dans le Gist (`edt.json`), que l'application lit. Le **contenu complet** de chaque mail est conservé (texte) — il est donc stocké dans ton Gist, pense-s'y si tu partages ou perds l'accès à ton compte GitHub. Pour ne garder que l'aperçu, le script bascule dessus si la lecture complète échoue.

Le mot de passe n'est jamais dans l'application ni dans le Gist : il est rangé chiffré dans les secrets du dépôt, que seul ce workflow peut lire. Ne le communiquer à personne.

1. Settings → Secrets and variables → Actions → **New repository secret**, trois fois :
   | Nom | Valeur |
   | --- | --- |
   | `UNICAEN_USER` | identifiant de l'ENT |
   | `UNICAEN_PASSWORD` | mot de passe de l'ENT |
   | `GIST_TOKEN` | le token de l'étape 2 |
2. Actions → **EDT Unicaen** → Run workflow (première récupération).
3. Dans l'application, le bouton Actualiser relance le workflow puis recharge l'EDT et les mails (environ 30 s).

Si le journal du workflow affiche une erreur 401, l'identifiant ou le mot de passe est refusé. GitHub suspend les tâches planifiées d'un dépôt sans activité depuis 60 jours : il suffit alors de relancer le workflow à la main. Pour ne pas récupérer les mails : Settings → Secrets and variables → Actions → onglet *Variables* → `MAILS` = `non`.

Sans ces secrets, un fichier `.ics` peut être importé depuis Paramètres → Unicaen.

Réglages facultatifs (secrets ou variables d'environnement du workflow) : `GIST_ID`, `EDT_SEMAINES_AVANT` (2), `EDT_SEMAINES_APRES` (16), `UNICAEN_AGENDA` (« Emploi du temps »), `MAILS_NB` (40).

### Moodle automatique (notes et cours, sans la grille)

Contrairement au site GEA, Moodle fonctionne avec un **jeton** (comme l'appli mobile officielle). Avec lui, le robot récupère tes cours et tes **notes** tout seul, sans la grille.

1. Sur Moodle : menu en haut à droite → **Préférences** → **Clefs de sécurité** (ou `ecampus-vert.unicaen.fr/user/managetoken.php`). Copie la valeur affichée dans la colonne « Clef ».
2. GitHub : Settings → Secrets and variables → Actions → **New repository secret** → nom `MOODLE_TOKEN`, valeur = cette clef.

Le robot ajoute alors tes notes dans l'onglet Moodle. Le jeton n'ouvre que Moodle et se **réinitialise** à tout moment depuis la même page (bouton « Réinitialiser ») — bien moins sensible que ton mot de passe ou ta grille. Si tu ne mets pas ce secret, Moodle se remplit seulement par le favori d'import.

Adresse Moodle différente ? Secret `MOODLE_URL`.

## 4. Site GEA et Moodle (favori d'import)

Le site GEA de l'IUT et Moodle passent par la connexion Unicaen avec code de la grille : ils ne peuvent pas être lus automatiquement. L'import se fait donc depuis une session ouverte, avec un favori.

**Créer le favori (une fois)** : dans l'application, Paramètres → Unicaen → **Favori d'import** (copie le code). Créer un favori quelconque dans le navigateur, puis le modifier : nom `→ Études`, adresse = coller le code (il commence par `javascript:`).
- Mac (Safari ou Chrome) : barre des favoris, clic droit → Modifier l'adresse.
- iPhone (Safari) : ajouter n'importe quelle page aux signets, puis Signets → Modifier → coller le code à la place de l'adresse.

**Importer** : se connecter au site GEA (www.iutcaen.unicaen.fr/gea) ou à Moodle (ecampus-vert.unicaen.fr), puis toucher le favori. Les données sont lues dans la page, puis l'application s'ouvre et les enregistre.
- Site GEA : absences, évaluations prévues (« Ma charge de travail ») et emploi du temps avec les examens signalés par l'IUT, sur 2 semaines passées et 12 à venir.
- Moodle : cours du semestre, sections et documents (liens vers Moodle), échéances (devoirs, tests).

Sur iPhone, Safari et l'application installée sur l'écran d'accueil ne partagent pas leurs données : connecter aussi la synchronisation Gist dans Safari (même token), l'import arrivera alors dans l'application par le Gist.

## 5. Emploi du temps : corrections

Dans un cours → **Modifier** : matière, intitulé, type (CM, TD, TP), examen oui/non, masquer. « Tous les cours identiques » applique la correction à tous les cours du même intitulé (ex. tous les « S1-C Outils de la decision »). « Rétablir » annule.

Lecture des intitulés : `S1-CM` = CM, `S1-C` = TD (groupe C), `S1-C2` = TP (groupe C2). Un cours marqué **CC** (et qui n'est pas un TP) est typé **CC** et compté comme examen. Sont aussi comptés comme examens ceux signalés par le site GEA, titrés « … — Matière » (format des épreuves), ou contenant examen, partiel, DS, contrôle continu ou terminal, rattrapage, soutenance, écrit, oral.

Les examens datés du site GEA (« Ma charge de travail ») qui n'apparaissent pas dans l'emploi du temps y sont ajoutés automatiquement comme blocs d'examen.

## 6. Examens → Notes

Chaque examen de l'emploi du temps et chaque évaluation du site GEA apparaît dans Notes comme note à venir (icône calendrier), dans la bonne ressource, avec sa date. Il suffit d'y saisir la note. Si l'examen disparaît ou n'est plus marqué comme tel, la ligne est retirée tant qu'aucune note n'a été saisie. Une ligne supprimée à la main ne revient pas.

## 7. Notes

La maquette du S1 BUT GEA (UE, ressources, coefficients du relevé ScoDoc) est préremplie ; Notes → Maquette pour l'ajuster ou créer le S2 (« Dupliquer » recopie la structure).

- Moyenne de ressource : moyenne des évaluations pondérée par leur coefficient (notes ramenées sur 20).
- Moyenne d'UE : moyenne des ressources notées pondérée par leurs coefficients, plus bonus, moins malus.
- « À viser » : note à obtenir partout où il reste à évaluer pour finir l'UE à 10. Une note laissée vide compte comme évaluation à venir ; une ressource sans évaluation compte comme entièrement à venir.

## 8. Formats d'import

QCM (fichier `.json` ou texte collé, plusieurs QCM possibles dans une liste) :

```json
{
  "titre": "Bilan",
  "matiere": "Comptabilité",
  "questions": [
    {
      "enonce": "Où figure le capital social ?",
      "propositions": ["Actif immobilisé", "Capitaux propres", "Dettes"],
      "reponses": [1],
      "explication": "Apport des associés : capitaux propres.",
      "theme": "Bilan"
    }
  ]
}
```

`reponses` contient les indices des bonnes propositions (0 = la première) ; les lettres (`"B"`) et plusieurs bonnes réponses sont acceptées. `matiere` peut être un code (`R1.07`) ou un intitulé.

Fiches : fichiers `.md` / `.txt` (le titre `# …` devient le titre de la fiche) ou JSON `{ "titre", "matiere", "contenu" }`. Mise en forme reconnue : `##` titres, `**gras**`, `==surligné==`, listes, `> encadré`, tableaux, `- [ ]` cases à cocher.

## Développement

```bash
npm install
npm run dev
```
